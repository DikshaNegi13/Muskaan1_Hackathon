package com.neueda.muskaan1.exception;

public class CustomerAlreadyExists extends Exception{
    public CustomerAlreadyExists(String message){
        super(message);
    }
}
